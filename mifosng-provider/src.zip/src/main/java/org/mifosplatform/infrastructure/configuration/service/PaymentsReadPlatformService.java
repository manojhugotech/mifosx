package org.mifosplatform.infrastructure.configuration.service;

public class PaymentsReadPlatformService {

}
