package org.mifosplatform.infrastructure.configuration.domain;

public interface ConfigurationDomainService {

    boolean isMakerCheckerEnabledForTask(String taskPermissionCode);

}
