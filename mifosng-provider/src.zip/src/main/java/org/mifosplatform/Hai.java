package org.mifosplatform;


public class Hai {
	public  static void main(String[] args) {

		System.out.println("hai");
	}

}
