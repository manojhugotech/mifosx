package org.mifosplatform.accounting.api.commands;


public class ProductToGLAccountMappingCommand {

}
