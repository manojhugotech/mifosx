package org.mifosplatform.portfolio.billingcycle.service;

public class BillingDays {

	private final int days;

	public BillingDays(int day) {

		this.days=day;
	}

	public int getDays() {
		return days;
	}


}
